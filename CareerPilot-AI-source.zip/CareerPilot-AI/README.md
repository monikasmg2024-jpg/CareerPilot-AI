# CareerPilot AI — Smart Career & Job Portal

A responsive, front-end portfolio demo for exploring sample job roles, practising interview questions, planning skills, and creating a starter resume draft.

## Features

- Responsive landing page and mobile navigation
- Search and filter sample job listings
- Save/unsave roles in the current page session
- View sample role descriptions
- Interview question practice tool
- Career-area skill planner
- Resume starter that downloads a plain-text draft locally in the browser
- No backend, account, or API key required

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

For the best local development experience, open the folder in VS Code and use the Live Server extension, or run a simple local web server.

## Publish with GitHub Pages

1. Create a GitHub repository named `CareerPilot-AI`.
2. Upload `index.html`, `styles.css`, `script.js`, and `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under the build/deployment section, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site and use the URL shown on the Pages settings screen.

## Important demo note

The job listings are sample portfolio content, not verified live vacancies. The site does not submit applications or send personal information to a server. The resume tool creates a local text draft only.
